# ProFit Up — site e pré-inscrições

O site salva as novas pré-inscrições no Firebase Realtime Database do projeto
`vm-variedades-ae402`, em `profitup/preinscricoes`.

Dados enviados: nome completo, telefone, e-mail, plano e data/hora gerada pelo
servidor do Firebase. A pré-inscrição confirma o recebimento somente depois de
o Firebase aceitar a gravação. O envio não abre o WhatsApp.

O painel `/admin` informa que o acesso administrativo está em configuração.
A consulta permanece bloqueada até configurarmos Firebase Authentication e
a autorização do UID administrador. Nenhuma senha de administrador foi criada.

## Regras e acesso

As regras do Realtime Database estão em `firebase/database.rules.json`.
O administrador futuro será autorizado pela entrada booleana
`profitup/admins/UID_DO_ADMIN = true`, criada no console pelo proprietário.
Essa entrada não pode ser alterada pelo site. Uma conta autenticada sem essa
permissão não consegue ler as pré-inscrições.

O código recusa novas gravações se detectar leitura pública das pré-inscrições.
As regras publicadas também devem continuar a validar os campos e impedir
alteração e exclusão de registros pelo formulário.

## Hospedagem

Este projeto é publicado com Sites e executa a API em Cloudflare Workers.
A interface pública está em `site-src/landing.html` e o envio é processado em
`app/api/pre-inscricoes/route.ts`.

A configuração pública do Firebase está em `lib/firebase-config.mjs`.
Nenhum segredo de conta de serviço ou senha faz parte do código.

O binding D1 existente é mantido para recibos de entrega (ID, hash do conteúdo
e data), usados para evitar reenvios confirmados. Os novos contatos não são
copiados para D1. Registros D1 antigos foram preservados, sem acesso pelo painel.
Não existe sincronização nem migração automática dos cadastros antigos.

## Desenvolvimento e testes

Use Node.js >=22.13 e o gerenciador indicado no package.json.
Instale as dependências do pnpm-lock.yaml, execute as migrações locais do D1
e use os comandos do projeto para desenvolvimento ou build.

- `node --experimental-vm-modules --test tests/registration.test.mjs`
- `node node_modules/typescript/bin/tsc --noEmit`
- `npm run build`

A produção e o banco Firebase não estão incluídos no ZIP. O projeto precisa de
servidor e configuração compatíveis; abrir um HTML local não executa a API.

A autenticação do administrador e a liberação de acesso público do site são
etapas separadas. A audiência atual da publicação não foi alterada.
