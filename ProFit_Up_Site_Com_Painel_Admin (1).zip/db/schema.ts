import { sqliteTable, text, index } from 'drizzle-orm/sqlite-core';
export const preregistrations = sqliteTable('preregistrations', {
 id: text('id').primaryKey(),
 fullName: text('full_name').notNull(),
 phone: text('phone').notNull(),
 email: text('email').notNull(),
 plan: text('plan').notNull(),
 createdAt: text('created_at').notNull(),
}, table=>[index('preregistrations_created_at_idx').on(table.createdAt),index('preregistrations_plan_idx').on(table.plan)]);
// Delivery receipts contain no customer contact details. Existing D1 records are retained.
export const firebaseRegistrationReceipts=sqliteTable('firebase_registration_receipts',{
 id:text('id').primaryKey(),
 payloadHash:text('payload_hash').notNull(),
 createdAt:text('created_at').notNull(),
});
