CREATE TABLE `firebase_registration_receipts` (
	`id` text PRIMARY KEY NOT NULL,
	`payload_hash` text NOT NULL,
	`created_at` text NOT NULL
);
