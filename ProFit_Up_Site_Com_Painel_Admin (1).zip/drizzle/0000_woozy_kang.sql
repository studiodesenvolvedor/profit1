CREATE TABLE `preregistrations` (
	`id` text PRIMARY KEY NOT NULL,
	`full_name` text NOT NULL,
	`phone` text NOT NULL,
	`email` text NOT NULL,
	`plan` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `preregistrations_created_at_idx` ON `preregistrations` (`created_at`);--> statement-breakpoint
CREATE INDEX `preregistrations_plan_idx` ON `preregistrations` (`plan`);