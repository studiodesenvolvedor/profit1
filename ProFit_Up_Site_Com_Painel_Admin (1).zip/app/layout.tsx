import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={title:'ProFit Up Academia — Timon',description:'Seu próximo nível começa aqui. Conheça os planos e faça sua pré-inscrição na ProFit Up.',icons:{icon:'/assets/logo-profit-up.png'}};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="pt-BR"><body>{children}</body></html>}
