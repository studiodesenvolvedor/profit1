import { env } from 'cloudflare:workers';
import { validateRegistration, sameOrigin } from '../../../lib/registration.mjs';
import {saveFirebaseRegistration,RegistrationConflict} from '../../../lib/firebase-registration.mjs';
export const dynamic='force-dynamic';
const noCache={'Cache-Control':'no-store'};
export async function POST(request: Request) {
 if(!sameOrigin(request))return Response.json({error:'Origem não autorizada.'},{status:403,headers:noCache});
 if(!request.headers.get('content-type')?.includes('application/json'))return Response.json({error:'Formato inválido.'},{status:415,headers:noCache});
 try {
  const body=await request.text();
  if(body.length>4096)return Response.json({error:'Dados excedem o tamanho permitido.'},{status:413,headers:noCache});
  let input;try{input=JSON.parse(body)}catch{return Response.json({error:'Dados inválidos.'},{status:400,headers:noCache})}
  const data=validateRegistration(input);
  if(!data)return Response.json({error:'Confira nome completo, telefone, e-mail e plano.'},{status:400,headers:noCache});
  if(!env.DB)throw new Error('Missing delivery receipt binding');
  await saveFirebaseRegistration(data,env.DB);
  return Response.json({ok:true},{status:201,headers:noCache});
 }catch(error){
  if(error instanceof RegistrationConflict)return Response.json({error:'Este envio já foi concluído com outros dados. Feche e abra o formulário para iniciar outro cadastro.'},{status:409,headers:noCache});
  return Response.json({error:'Não foi possível confirmar o envio da pré-inscrição. Tente novamente ou entre em contato com a academia.'},{status:503,headers:noCache});
 }
}
