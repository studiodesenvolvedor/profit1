export const dynamic='force-dynamic';
export async function GET() {
 return Response.json({error:'A consulta das pré-inscrições será liberada após a configuração do acesso administrativo.'},{status:503,headers:{'Cache-Control':'no-store, private'}});
}
