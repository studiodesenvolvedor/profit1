export const dynamic='force-dynamic';
export const metadata={title:'Administração | ProFit Up',robots:{index:false,follow:false}};
export default function AdminPage(){
 return <main className="access-card"><span className="eyebrow">PROFIT UP · ADMINISTRAÇÃO</span><h1>Acesso administrativo em configuração.</h1><p>As pré-inscrições são recebidas pela academia. A consulta dos dados será liberada após a configuração do acesso do administrador.</p><a className="button" href="/">Voltar ao site</a></main>;
}
