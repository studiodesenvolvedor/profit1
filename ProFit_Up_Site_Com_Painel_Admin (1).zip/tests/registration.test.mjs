import {test} from 'node:test';import assert from 'node:assert/strict';import vm from 'node:vm';import fs from 'node:fs';import path from 'node:path';import {DatabaseSync} from 'node:sqlite';import {webcrypto} from 'node:crypto';import ts from 'typescript';import {validateRegistration,PLANS,sameOrigin} from '../lib/registration.mjs';import {saveFirebaseRegistration,RegistrationConflict} from '../lib/firebase-registration.mjs';
const payload={requestId:'12345678-1234-4123-8123-123456789012',fullName:'Cliente de Teste',phone:'(86) 99999-1234',email:'teste@example.com',plan:'Mensal'};
function database(){const sql=new DatabaseSync(':memory:');for(const f of fs.readdirSync('drizzle').filter(x=>x.endsWith('.sql')).sort())sql.exec(fs.readFileSync('drizzle/'+f,'utf8').replaceAll('--> statement-breakpoint',''));const DB={prepare(query){return{bind(...args){return{async first(){return sql.prepare(query).get(...args)||null},async run(){sql.prepare(query).run(...args);return{success:true}}}}}}};return{sql,DB};}
test('validates all plans and rejects malformed contact data or origins',()=>{for(const plan of PLANS)assert(validateRegistration({...payload,plan}));for(const change of [{plan:'Admin'},{fullName:'A'},{phone:'123'},{email:'not-an-email'},{requestId:'1'}])assert.equal(validateRegistration({...payload,...change}),null);assert(!sameOrigin(new Request('https://test.site/api',{headers:{Origin:'https://evil.site'}})))});
test('Firebase uses correct path and server timestamp; duplicate receipt avoids repeat write',async()=>{
 const{sql,DB}=database();const requests=[];const fetchImpl=async(url,options)=>{requests.push({url,options});return options.method==='GET'?new Response(null,{status:401}):Response.json({createdAt:123})};
 const data=validateRegistration(payload);await saveFirebaseRegistration(data,DB,{fetchImpl});assert.equal(requests.length,2);assert(requests[1].url.endsWith('/profitup/preinscricoes/'+payload.requestId+'.json'));const sent=JSON.parse(requests[1].options.body);assert.equal(sent.phone,'86999991234');assert.equal(sent.plan,'Mensal');assert.deepEqual(sent.createdAt,{'.sv':'timestamp'});
 await saveFirebaseRegistration(data,DB,{fetchImpl});assert.equal(requests.length,2);
 await assert.rejects(()=>saveFirebaseRegistration({...data,plan:'Anual'},DB,{fetchImpl}),RegistrationConflict);
 assert.equal(sql.prepare('select count(*) n from preregistrations').get().n,0);const receipt=sql.prepare('select * from firebase_registration_receipts').get();assert.equal(receipt.id,payload.requestId);assert(!JSON.stringify(receipt).includes('teste@example.com'));sql.close();
});
test('insecure rules and refused writes never produce a success receipt',async()=>{
 const{sql,DB}=database();const data=validateRegistration(payload);let calls=0;
 await assert.rejects(()=>saveFirebaseRegistration(data,DB,{fetchImpl:async()=>{calls++;return Response.json(null)}}));assert.equal(calls,1);
 await assert.rejects(()=>saveFirebaseRegistration(data,DB,{fetchImpl:async(url,o)=>new Response(null,{status:o.method==='GET'?401:403})}));assert.equal(sql.prepare('select count(*) n from firebase_registration_receipts').get().n,0);sql.close();
});
test('API saves to Firebase and keeps administrative access blocked',async()=>{
 const{sql,DB}=database();let rejected=false;const fetchImpl=async(url,o)=>new Response(null,{status:o.method==='GET'?401:rejected?403:200});
 const context=vm.createContext({Response,Request,URL,Date,Number,JSON,Error,crypto:webcrypto,TextEncoder,AbortSignal,fetch:fetchImpl,console:{warn(){}}});const cache=new Map();
 const cloudflare=new vm.SyntheticModule(['env'],function(){this.setExport('env',{DB})},{context});
 async function load(file){file=path.resolve(file);if(cache.has(file))return cache.get(file);let src=fs.readFileSync(file,'utf8');if(file.endsWith('.ts'))src=ts.transpileModule(src,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;const mod=new vm.SourceTextModule(src,{context,identifier:file});cache.set(file,mod);await mod.link(spec=>spec==='cloudflare:workers'?cloudflare:load(path.resolve(path.dirname(file),spec)));return mod;}
 const write=await load('app/api/pre-inscricoes/route.ts');await write.evaluate();const read=await load('app/api/admin/pre-inscricoes/route.ts');await read.evaluate();
 const req=(data,origin='https://test.site')=>new Request('https://test.site/api/pre-inscricoes',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},body:JSON.stringify(data)});
 assert.equal((await write.namespace.POST(req(payload))).status,201);assert.equal((await write.namespace.POST(req(payload))).status,201);assert.equal((await write.namespace.POST(req({...payload,phone:'1'}))).status,400);assert.equal((await write.namespace.POST(req(payload,'https://evil.site'))).status,403);
 const response=await read.namespace.GET();assert.equal(response.status,503);assert(!(await response.text()).includes('teste@example.com'));
 rejected=true;assert.equal((await write.namespace.POST(req({...payload,requestId:'23456789-1234-4123-8123-123456789012'}))).status,503);assert.equal(sql.prepare('select count(*) n from firebase_registration_receipts').get().n,1);sql.close();
});
